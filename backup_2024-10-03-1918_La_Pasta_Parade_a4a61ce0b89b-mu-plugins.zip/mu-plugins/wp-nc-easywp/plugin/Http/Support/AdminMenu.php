<?php

namespace WPNCEasyWP\Http\Support;

class AdminMenu
{
    const NONCE            = 'wpnceasywp';
    const ACTION_KEY       = 'wpnceasywp_action';
    const ACTION_CLEAR_ALL = 'clear_all';
    const PARENT_MENU_ID   = 'wpnceasywp-admin-menu';
}