<?php

namespace WPNCEasyWP\Http\Controllers;

use WPNCEasyWP\WPBones\Routing\Controller as BaseController;

abstract class Controller extends BaseController
{

}