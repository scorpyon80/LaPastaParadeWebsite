=== WPNCEasyWP ===
Contributors: gfazioli
Donate link: https://www.namecheap.com/support/knowledgebase/article.aspx/10015/2279/easywp-plugins-cache-plugin-seo-plugin-and-blocked-plugins/
Tags: wordpress
Requires at least: 6.2.2
Tested up to: 6.5.2
Stable tag: 1.4.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WordPress Namecheap EasyWP plugin.

== Description ==

WPNCEasyWP boilerplate plugin

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload the entire content of plugin archive to your `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress (deactivate and reactivate if you're upgrading).
3. Done. Enjoy.

== Frequently Asked Questions ==

= What is WP Bones framework ? =

See detail to  ([WP Bones](http://wpbones.github.io/WPBones)).

== Screenshots ==

Your screenshot

== Changelog ==

= 1.0.6 =

- Removes unused

= 0.9.0 =

* Updates WP Bones v1.0+

= 0.8.1 =

* Adds ClickerVolt in the banned plugin list

= 0.8.0 =

* Fixes the PSR-4 autoload
* Improves (temporary) the WPBones core config
* Adds the Heartbeat management

= 0.7.3 =

* Increase the heartbeat_interval

= 0.7.2 =

* Adds cs-panel auto admin login support

= 0.7.1 =

* Adds a new banned plugin

= 0.7.0 =

* Adds the ability to redirect to a specific page

= 0.6.0 =

* Adds compaibility with Next JS version of Dashboard