<?php

/* Metaboxes activation */
/* Tgm activation */

require_once get_template_directory() . '/inc/libs/tgm/class-tgm-init.php';
?>